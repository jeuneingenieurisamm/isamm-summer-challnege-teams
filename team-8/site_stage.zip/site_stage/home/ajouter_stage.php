<?php
$connect = mysqli_connect("localhost", "root", "",'stage_affect');
$cin=$_POST['cin'];
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$niveau=$_POST['niveau'];
$formation=$_POST['formation'];
$typeStage=$_POST['typeStage'];
$dateD=$_POST['dateD'];
$dateF=$_POST['dateF'];
$nomE=$_POST['nomE'];
$email=$_POST['email'];
$query = "INSERT into stage(cinEtu, nomEtu, prenomEtu, niveauEtu, formationEtu,typeStage, dateD, dateF, nomEnt, emailEtu) values('$cin','$nom','$prenom','$niveau','$formation','$typeStage','$dateD', '$dateF','$nomE','$email')";
mysqli_query($connect, $query);
header('Location: home.html');
$q="select * from stage";
$r=mysqli_query($connect, $q);
echo "<table border=2>";
foreach ($r as $key) {
  echo "<tr>";
  foreach ($key as $key1 => $value) {
    echo "<td>";
    echo "t[$key1]=$value <br/>";
    echo "</td>";
  }
  echo "</tr>";
}
echo "</table>";
?>
