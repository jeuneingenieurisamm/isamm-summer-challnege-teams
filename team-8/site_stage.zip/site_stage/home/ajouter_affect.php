<?php
$connect = mysqli_connect("localhost", "root", "",'stage_affect');
$cin=$_POST['cin2'];
$nom=$_POST['nom2'];
$prenom=$_POST['prenom2'];
$niveau=$_POST['niveau2'];
$formation=$_POST['formation2'];
$typeStage=$_POST['typeStage2'];
$dateD=$_POST['dateD2'];
$dateF=$_POST['dateF2'];
$nomE=$_POST['nomE2'];
$email=$_POST['email2'];
$query = "INSERT into lettreaff(cinEtu, nomEtu, prenomEtu, niveauEtu, formationEtu,typeStage, nomEnt, emailEtu, dateD, dateF) values('$cin','$nom','$prenom','$niveau','$formation','$typeStage','$nomE','$email','$dateD', '$dateF')";
mysqli_query($connect, $query);
header('Location: home.html');
?>
