<!DOCTYPE html>
<html>
<head>
<style>
table {
    width: 100%;
}
table, th {
  border: none;
  border-bottom: solid #036;
}
td {text-align: center;}
</style>
</head>
<body>
  <?php
  $connect = mysqli_connect("localhost", "root", "", "stage_affect");
  $output = '';
  if(isset($_POST["query"]))
  {
   $search = mysqli_real_escape_string($connect, $_POST["query"]);
   $query = "SELECT * from liste_csv where cinEtu != 0 and cinEtu LIKE '%".$search."%'";
  }
  else
  {
   $query = "SELECT * FROM liste_csv where cinEtu != 0 ORDER BY cinEtu";
  }
  $result = mysqli_query($connect, $query);
   $output .= '
    <div>
     <table>
      <tr>
       <th><h3>CIN</h3></th>
       <th><h3>NOM</h3></th>
       <th><h3>PRENOM</h3></th>
      </tr>
   ';
   while($row = mysqli_fetch_array($result))
   {
    $output .= '
     <tr>
      <td>'.$row["cinEtu"].'</td>
      <td>'.$row["nomEtu"].'</td>
      <td>'.$row["prenomEtu"].'</td>
     </tr>
    ';
   }
   echo $output;
  ?>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
