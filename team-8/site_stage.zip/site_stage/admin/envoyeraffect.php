﻿<!DOCTYPE html>
<html>
<head>
</head>
<body>
<?php
include('pdf.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'phpmailer/vendor/autoload.php';
$connect = mysqli_connect("localhost", "root", "", "stage_affect");
if(isset($_POST["id"]))
{
 foreach($_POST["id"] as $id)
 {
   $query1 = "SELECT * FROM lettreaff where cinEtu = $id";
   $result = mysqli_query($connect, $query1);
   $row = mysqli_fetch_array($result);
   $file_name = $row["nomEtu"].' '.$row["prenomEtu"].'.pdf';
   $html_code = "<img src='img/entetePDF.png' style='width:100%'/>
                 <div class='demandestage' style='text-align:center;padding:50px;
                 font-family: Gotham, Helvetica, Arial'>
                   <h2>LETTRE D'AFFECTATION</h2>
                 </div>";
  $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
               font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
                 <b>Nom et prénom:</b> ".$row['nomEtu']." ".$row['prenomEtu']."
               </div>";
  $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
            font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
              <b>CIN:</b> ".$row['cinEtu']."
            </div>";
if ($row['formationEtu']=='ing') {
  $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
            font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
            <b>Formation :</b> Cycle ingénieur en informatique multimédia
            </div>";
}
else {
  if ($row['formationEtu']=='im') {
    $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
              font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
              <b>Formation :</b> Licence fondamentale en Informatique  et  Multimédia (IM)
              </div>";
  }
  else {
    if ($row['formationEtu']=='cm') {
      $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
                font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
                <b>Formation :</b> Licence appliquée en Communication Multimédia (CM)
                </div>";
    }
    else {
      if ($row['formationEtu']=='av') {
        $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
                  font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
                  <b>Formation :</b> Licence appliquée en cinéma et audiovisuel
                  </div>";
      }
    }
  }
}
 if ($row['niveauEtu']=='premiere') {
   $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
             font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
               <b>niveau :</b> 1ère année </div>";
 }
 else {
   if ($row['niveauEtu']=='deuxieme') {
     $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
               font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
                 <b>niveau :</b> 2ème année </div>";
   }
   else {
     if ($row['niveauEtu']=='troisieme') {
       $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
                 font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
                   <b>niveau :</b> 3ème année </div>";
     }
   }
 }

 if ($row['typeStage']=='pfe') {
   $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
                font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
                  <b>dans le cadre d’un :</b> stage de fin d'études
                </div>";
 }
 else {
   if ($row['typeStage']=='obligatoire') {
     $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
                  font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
                    <b>Type du stage :</b> stage obligatoire
                  </div>";
   }
   else {
     if ($row['typeStage']=='non_obligatoire') {
       $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
                    font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
                      <b>dans le cadre d’un :</b> stage non obligatoire
                    </div>";
     }
   }
 }
 $html_code .= "<div class='objet' style='text-align-last:justify; margin-left:50px;
             font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
               <b>Nom de l’entreprise d’accueil : </b>".$row['nomEnt']."
             </div>";
 $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
              font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
                <b>Période : </b>".$row['dateD']." au ".$row['dateF']."
              </div>";
 $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
             font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
               &nbsp;&nbsp;&nbsp;&nbsp;Restant à votre disposition pour tout complément d’information, nous vous
               prions d’agréer, madame, monsieur, l’expression de nos salutations distinguées.<br/><br/>Cordialement,<br/><br/>
               Youssef Ben Halima<br/>Directeur des études et des stages - ISAMM<br/>Tél : 71 603.497<br/>Fax : 71 603.450
             </div>";


   $pdf = new Pdf();
   $pdf->load_html($html_code);
   $pdf->render();
   $file = $pdf->output();
   file_put_contents('..\LettreAffectPDF/'.$file_name, $file);


   $mail = new PHPMailer(true);
   try {
       $mail->SMTPDebug = 2;
       $mail->isSMTP();
       $mail->Host = 'smtp.gmail.com';
       $mail->SMTPAuth = true;
       $mail->Username = 'isamm.internship@gmail.com';
       $mail->Password = 'isamm2018';
       $mail->SMTPSecure = 'tls';
       $mail->Port = 587;
       $mail->setFrom('isamm.internship@gmail.com');
       $mail->addAddress("$row[emailEtu]");
       $mail->isHTML(true);
       $mail->AddAttachment('..\LettreAffectPDF/'.$file_name);
       $mail->Subject = 'LETTRE D\'AFFECTATION';
       $mail->Body    = $row["nomEtu"].' '.$row["prenomEtu"].'<br>Vous trouvez ci-joint votre demande de stage sign&eacute;e.';
       $mail->send();
       echo 'Message has been sent';
   } catch (Exception $e) {
       echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
   }


   $query = "DELETE FROM lettreaff WHERE cinEtu = '".$id."'";
   mysqli_query($connect, $query);
   $html_code="";
 }
}
?>
</body>
</html>
