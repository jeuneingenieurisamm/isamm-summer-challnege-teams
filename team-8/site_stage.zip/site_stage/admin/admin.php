﻿<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="img/logo isamm.png" />
<link rel="stylesheet" type="text/css" href="cssfile.css" />
<link rel="stylesheet" type="text/css" href="css/cssfileAdmin.css" />
<link rel="stylesheet" type="text/css" href="css/Squares.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title>ISAMM</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function() {
  $("a").on('click', function(event) {
    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function() {
        window.location.hash = hash;
      });
    }
  });
});
$(window).scroll(function(){

    if($(this).scrollTop() >= 510 && $(this).scrollTop() <= 550)
    {
        $(".titre").delay(1000).fadeIn().css({"visibility":"visible"});
    }
});
</script>
<script>
$(document).ready(function() {
var time = document.getElementById("time");
var ctx = time.getContext("2d");
var width = (time.width = window.innerWidth);
var height = (time.height = window.innerHeight);

setInterval(function() {
  var currentTime = new Date();
  var formattedTime = currentTime.toLocaleTimeString();

  ctx.clearRect(0, 0, width, height);
  ctx.font = "100% Lato, sans-serif";
  ctx.fillStyle = '#036';
  ctx.textAlign = "center";
  if((formattedTime>"12:00:00")&&(formattedTime<"23:59:59"))
  {
    ctx.fillText(formattedTime+" pm", width/2 , height/1.5 );
  }
  else
  {
    ctx.fillText(formattedTime+" am", width/2 , height/1.5 );
  }
}, 1000);
});
</script>

</head>
<body onload="myFunction()" style="margin:0;">
  <div id="loader">
    <div class="square"></div>
    <div class="square"></div>
    <div class="square last"></div>
    <div class="square clear"></div>
    <div class="square"></div>
    <div class="square last"></div>
    <div class="square clear"></div>
    <div class="square "></div>
    <div class="square last"></div>
  </div>
  <div id="wrapper" style="display:none; background-color:#fff">
    <div class="header-wrapper">
      <header>
        <div class="bg">
          <nav>
            <a href="admin.html"><img src="img/logo isamm.png" class="logo" /></a>
            <div class="navbar">
              <a href="admin.php">Accueil</a>
              <a href="#services">Services</a>
            </div>
          </nav>
          <canvas id="time">
          </canvas>
          <div class="admin">Administration</div>
        </div>
      </header>
    </div>
    <div id="services">
      <div class="rapide">
        POUR UN CONTACT PLUS EFFICACE AVEC NOS ETUDIANTS
      </div>
      <div id="verifiersect">
        <div class="titre"  style="visibility: hidden;margin-bottom:40px;">
          <div class="leftside"></div>
          <div class="verif">
            VERIFIER LES DROITS DE STAGE
          </div>
        </div>
        <div id="recherche" style="color:#036;margin-left:40px">
          <p><label for="search_text">Saisir le n° cin de l'étudiant :</label></p>
          <input type="text" name="search_text" id="search_text" placeholder="Rechercher" class="form-control"
          style="color:#036;margin:20px;padding:10px;border:1px #036 solid;border-radius:4px;"/>
        </div>
        <div class="listecsv">
          <div id="result"></div>
        </div>
      </div>
      <div id="stagesect">
        <div class="titre" style="visibility: hidden;margin-bottom:40px;">
          <div class="consult">
            ENVOYER LES DEMANDES DE STAGE
          </div>
          <div class="leftside"></div>
        </div>
        <div class="listedemande">
          <div id="liste">
            <?php
            $connect = mysqli_connect("localhost", "root", "",'stage_affect');

            $q="select * from stage where cinEtu != 0";
            $r=mysqli_query($connect, $q);
            echo "<table>";
            echo "<tr>";
            echo "<th><h3>CIN</h3></th>";
            echo "<th><h3>NOM</h3></th>";
            echo "<th><h3>PRENOM</h3></th>";
            echo "<th><h3>NIVEAU</h3></th>";
            echo "<th><h3>FORMATION</h3></th>";
            echo "<th><h3>TYPE DE STAGE</h3></th>";
            echo "<th><h3>DATE DEBUT</h3></th>";
            echo "<th><h3>DATE FIN</h3></th>";
            echo "<th><h3>NOM D'ENTREPRISE</h3></th>";
            echo "<th><h3>EMAIL</h3></th>";
            echo "<th><i class='fa fa-check-square-o'></i></th>";
            echo "</tr>";
            while($row=mysqli_fetch_array($r))
            {
              ?>
              <tr id="<?php echo $row["cinEtu"];?>">
                <td><?php echo $row["cinEtu"];?></td>
                <td><?php echo $row["nomEtu"];?></td>
                <td><?php echo $row["prenomEtu"];?></td>
                <td><?php echo $row["niveauEtu"];?></td>
                <td><?php echo $row["formationEtu"];?></td>
                <td><?php echo $row["typeStage"];?></td>
                <td><?php echo $row["dateD"];?></td>
                <td><?php echo $row["dateF"];?></td>
                <td><?php echo $row["nomEnt"];?></td>
                <td><?php echo $row["emailEtu"];?></td>
                <td><input type=checkbox name="Etu[]" class="box" value="<?php echo $row["cinEtu"];?>"/></td>
              </tr>
              <?php
            }
            echo "</table>";
            ?>
          </div>
          <p>
            <div align="center">
              <button name="validerbutt" id="validerbutt" type="button" class="validerbutt">Valider</button>
              <button name="deletebutt" id="deletebutt" type="button" class="deletebutt">Supprimer</button>
            </div>
          </p>
        </div>
      </div>
      <div id="affectsect">
        <div class="titre" style="visibility: hidden;margin-bottom:40px;">
          <div class="leftside"></div>
          <div class="affect">
            ENVOYER LES LETTRES D'AFFECTATION
          </div>
        </div>
        <div class="listelettre">
          <div id="liste">
            <?php
            $connect = mysqli_connect("localhost", "root", "",'stage_affect');

            $q="select * from lettreaff where cinEtu != 0";
            $r=mysqli_query($connect, $q);
            echo "<table>";
            echo "<tr>";
            echo "<th><h3>CIN</h3></th>";
            echo "<th><h3>NOM</h3></th>";
            echo "<th><h3>PRENOM</h3></th>";
            echo "<th><h3>NIVEAU</h3></th>";
            echo "<th><h3>FORMATION</h3></th>";
            echo "<th><h3>TYPE DE STAGE</h3></th>";
            echo "<th><h3>DATE DEBUT</h3></th>";
            echo "<th><h3>DATE FIN</h3></th>";
            echo "<th><h3>NOM D'ENTREPRISE</h3></th>";
            echo "<th><h3>EMAIL</h3></th>";
	    echo "<th><i class='fa fa-check-square-o'></i></th>";
            echo "</tr>";
            while($row=mysqli_fetch_array($r))
            {
              ?>
              <tr id="<?php echo $row["cinEtu"];?>">
                <td><?php echo $row["cinEtu"];?></td>
                <td><?php echo $row["nomEtu"];?></td>
                <td><?php echo $row["prenomEtu"];?></td>
                <td><?php echo $row["niveauEtu"];?></td>
                <td><?php echo $row["formationEtu"];?></td>
                <td><?php echo $row["typeStage"];?></td>
                <td><?php echo $row["dateD"];?></td>
                <td><?php echo $row["dateF"];?></td>
                <td><?php echo $row["nomEnt"];?></td>
                <td><?php echo $row["emailEtu"];?></td>
                <td><input type=checkbox name="Etu[]" class="box" value="<?php echo $row["cinEtu"];?>"/></td>
              </tr>
              <?php
            }
            echo "</table>";
            ?>
          </div>
          <p>
            <div align="center">
              <button name="validerbutt_aff" id="validerbutt_aff" type="button" class="validerbutt_aff">Valider</button>
              <button name="deletebutt_aff" id="deletebutt_aff" type="button" class="deletebutt_aff">Supprimer</button>
            </div>
          </p>
        </div>
      </div>
    </div>
    <footer>All Rights Reserved.<br>Malèk et Louay &copy; 2018</footer>
  </div>
  <script>
    var x;

    function myFunction() {
        x = setTimeout(showPage, 3000);
    }

    function showPage() {
      document.getElementById("loader").style.display = "none";
      document.getElementById("wrapper").style.display = "block";
    }
  </script>
  <script>
  $(document).ready(function(){
      $("#deletebutt").click(function(){
        if(confirm("Êtes-vous sûr ?"))
        {
           var id = [];

           $(':checkbox:checked').each(function(i){
            id[i] = $(this).val();
          });

         if(id.length === 0)
         {
          alert("Veuillez sélectionner au moins une case à cocher");
         }
         else
         {
          $.ajax({
           url:'deletestage.php',
           method:'POST',
           data:{id:id},
           success:function(){
              for(var i=0; i<id.length; i++)
              {
                 $('tr#'+id[i]+'').css('background-color', '#ccc');
                 $('tr#'+id[i]+'').fadeOut('slow');
              }
            }
          });
         }
        }
        else
        {
         return false;
        }
      });
  });
  $(document).ready(function(){
      $("#validerbutt").click(function(){
        if(confirm("Êtes-vous sûr ?"))
        {
           var id = [];

           $(':checkbox:checked').each(function(i){
            id[i] = $(this).val();
          });

         if(id.length === 0)
         {
          alert("Veuillez sélectionner au moins une case à cocher");
         }
         else
         {
          $.ajax({
           url:'envoyerdemande.php',
           method:'POST',
           data:{id:id},
           success:function(){
              for(var i=0; i<id.length; i++)
              {
                 $('tr#'+id[i]+'').css('background-color', '#ccc');
                 $('tr#'+id[i]+'').fadeOut('slow');
              }
            }
          });
         }
        }
        else
        {
         return false;
        }
      });
  });
  $(document).ready(function(){
      $("#deletebutt_aff").click(function(){
        if(confirm("Êtes-vous sûr ?"))
        {
           var id = [];

           $(':checkbox:checked').each(function(i){
            id[i] = $(this).val();
          });

         if(id.length === 0)
         {
          alert("Veuillez sélectionner au moins une case à cocher");
         }
         else
         {
          $.ajax({
           url:'deleteaffect.php',
           method:'POST',
           data:{id:id},
           success:function(){
              for(var i=0; i<id.length; i++)
              {
                 $('tr#'+id[i]+'').css('background-color', '#ccc');
                 $('tr#'+id[i]+'').fadeOut('slow');
              }
            }
          });
         }
        }
        else
        {
         return false;
        }
      });
  });
  $(document).ready(function(){
      $("#validerbutt_aff").click(function(){
        if(confirm("Êtes-vous sûr ?"))
        {
           var id = [];

           $(':checkbox:checked').each(function(i){
            id[i] = $(this).val();
          });

         if(id.length === 0)
         {
          alert("Veuillez sélectionner au moins une case à cocher");
         }
         else
         {
          $.ajax({
           url:'envoyeraffect.php',
           method:'POST',
           data:{id:id},
           success:function(){
              for(var i=0; i<id.length; i++)
              {
                 $('tr#'+id[i]+'').css('background-color', '#ccc');
                 $('tr#'+id[i]+'').fadeOut('slow');
              }
            }
          });
         }
        }
        else
        {
         return false;
        }
      });
  });
  $(document).ready(function(){

 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"recherche.php",
   method:"POST",
   data:{query:query},
   success:function(data)
   {
    $('#result').html(data);
   }
  });
 }
 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
 });
});
</script>
</body>
</html>
