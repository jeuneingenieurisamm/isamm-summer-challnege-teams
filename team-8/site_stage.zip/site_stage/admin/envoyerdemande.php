﻿<!DOCTYPE html>
<html>
<head>
</head>
<body>
<?php
include('pdf.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'phpmailer/vendor/autoload.php';
$connect = mysqli_connect("localhost", "root", "", "stage_affect");
if(isset($_POST["id"]))
{
 foreach($_POST["id"] as $id)
 {
   $query1 = "SELECT * FROM stage where cinEtu = $id";
   $result = mysqli_query($connect, $query1);
   $row = mysqli_fetch_array($result);
   $file_name = $row["nomEtu"].' '.$row["prenomEtu"].'.pdf';
   if(($row["formationEtu"]=="im")||($row["formationEtu"]=="cm"))
   {
     $html_code = "<img src='img/entetePDF.png' style='width:100%'/>
                   <div class='demandestage' style='text-align:center;padding:50px;
                   font-family: Gotham, Helvetica, Arial'>
                     <h2>A l'attention du directeur général</h2>
                   </div>";
     $html_code .= "<div class='Mme_Mr' style='text-align:left;margin-left:100px;
                   font-family: Gotham, Helvetica, Arial; margin-bottom:25px'>
                     Madame, Monsieur
                   </div>";
     $html_code .= "<div class='texte' >
                     <div class='p1' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:10px;
                     font-family: Gotham, Helvetica, Aria'>
                      &nbsp;&nbsp;&nbsp;&nbsp;Dans le cadre de la formation dispensée à l’Institut Supérieur des Arts
                       Multimédias de la Manouba (ISAMM), nous avons pour mission de former
                       des étudiants ayant des compétences nécessaires pour une intégration
                       dans le monde du travail et de l’entreprise en leur offrant une formation
                       professionnelle et spécialisée en <b><i>Informatique et Multimédia</i></b> ainsi qu’en
                       <b><i>Communication Multimédia</i></b>.
                     </div>
                     <div class='p2' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:10px;
                     font-family: Gotham, Helvetica, Arial;'>
                      &nbsp;&nbsp;&nbsp;&nbsp;Cette formation repose en partie sur l’insertion des étudiants au sein d’entreprises
                      dans le cadre de stages et stages de fin d’études.
                     </div>
                     <div class='p3' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:10px;
                     font-family: Gotham, Helvetica, Arial;'>
                    &nbsp;&nbsp;&nbsp;&nbsp;Nous venons par la présente vous demander de bien vouloir nous donner votre accord de
                    principe pour l’insertion de certains étudiants de l’ISAMM au sein de votre entreprise
                    en tant que stagiaires. Les étudiants pourront être issus de la filière
                    <b><i>Informatique et Multimédia</i></b> ainsi que de la filière <b><i>Communication Multimédia</i></b>
                    vue que ces deux formations sont complémentaires.
                     </div>
                     <div class='p4' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:10px;
                     font-family: Gotham, Helvetica, Arial;'>
                      &nbsp;&nbsp;&nbsp;&nbsp;Nous portons à votre attention que nous disposons également de la possibilité d’établir
                      des accords de partenariat via des conventions qui permettent de faire bénéficier les
                      entreprises d’accueil du signe d’ « établissement formateur » (<i>Loi n° 2009-21 du 28 avril
                      2009, fixant le cadre général de la formation pratique des étudiants de l’enseignement
                      supérieur au sein des administrations, des entreprises ou des établissements publics ou privés</i>).
                     </div>
                     <div class='p5' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:25px;
                     font-family: Gotham, Helvetica, Arial;'>
                    &nbsp;&nbsp;&nbsp;&nbsp;Restant à votre disposition pour tout complément d’information, nous vous prions d’agréer,
                       madame, monsieur, l’expression de nos salutations distinguées. <br/>Cordialement,
                     </div>
                     <div class='signature' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:10px;
                     font-family: Gotham, Helvetica, Arial;'>
                      Youssef Ben Halima<br/>Directeur des études et des stages - ISAMM<br/>Tél : 71 603.497<br/>Fax : 71 603.450
                     </div>
                   </div>";
       $html_code .= "<img src='img/entetePDF.png' style='width:100%'/>
                     <div class='demandestage' style='text-align:center;padding:50px;
                     font-family: Gotham, Helvetica, Arial'>
                       <h2>A l'attention du directeur général</h2>
                     </div>";
   }
   else {
     if($row["formationEtu"]=="av")
     {
       $html_code = "<img src='img/entetePDF.png' style='width:100%'/>
                     <div class='demandestage' style='text-align:center;padding:50px;
                     font-family: Gotham, Helvetica, Arial'>
                       <h2>A l’attention de madame, monsieur le responsable des  ressources humaines</h2>
                     </div>";
       $html_code .= "<div class='Mme_Mr' style='text-align:left;margin-left:100px;
                     font-family: Gotham, Helvetica, Arial; margin-bottom:25px'>
                       Madame, Monsieur
                     </div>";
       $html_code .= "<div class='texte' >
                       <div class='p1' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:10px;
                       font-family: Gotham, Helvetica, Aria'>
                      &nbsp;&nbsp;&nbsp;&nbsp;Dans le cadre des formations dispensées à l’Institut Supérieur des Arts Multimédias
                      de la Manouba (ISAMM), nous avons la mission de former des étudiants en
                      licence appliquée en <b><i>Cinéma audiovisuel</i></b> avec quatre spécialités : <b><i>Ecriture et
                      assistanat à la réalisation, montage, direction photo et son</i></b>.
                       </div>
                       <div class='p2' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:10px;
                       font-family: Gotham, Helvetica, Arial;'>
                        &nbsp;&nbsp;&nbsp;&nbsp;Cette formation repose en partie sur l’insertion des étudiants au sein d’entreprises dans le cadre de stages
                        d’été (stages facultatifs).
                       </div>
                       <div class='p3' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:10px;
                       font-family: Gotham, Helvetica, Arial;'>
                      &nbsp;&nbsp;&nbsp;&nbsp;Nous venons par la présente vous demander de bien vouloir nous donner votre accord de principe pour l’insertion
                      de certains étudiants de l’ISAMM au sein de votre entreprise en tant que stagiaires.
                       </div>
                       <div class='p4' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:10px;
                       font-family: Gotham, Helvetica, Arial;'>
                        &nbsp;&nbsp;&nbsp;&nbsp;Nous portons à votre attention que nous disposons également de la possibilité d’établir
                        des accords de partenariat via des conventions qui permettent de faire bénéficier les
                        entreprises d’accueil du signe d’ « établissement formateur » (<i>Loi n° 2009-21 du 28 avril
                        2009, fixant le cadre général de la formation pratique des étudiants de l’enseignement
                        supérieur au sein des administrations, des entreprises ou des établissements publics ou privés</i>).
                       </div>
                       <div class='p5' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:25px;
                       font-family: Gotham, Helvetica, Arial;'>
                        &nbsp;&nbsp;&nbsp;&nbsp;Restant à votre disposition pour tout complément d’information, nous vous prions d’agréer,
                         madame, monsieur, l’expression de nos salutations distinguées. <br/>Cordialement,
                       </div>
                       <div class='signature' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:50px;
                       font-family: Gotham, Helvetica, Arial;'>
                        Youssef Ben Halima<br/>Directeur des études et des stages - ISAMM<br/>Tél : 71 603.497<br/>Fax : 71 603.450
                       </div>
                     </div>";
         $html_code .= "<img src='img/entetePDF.png' style='width:100%'/>
                       <div class='demandestage' style='text-align:center;padding:50px;
                       font-family: Gotham, Helvetica, Arial'>
                         <h2>A l’attention de madame, monsieur le responsable des  ressources humaines</h2>
                       </div>";
     }
     else {
       if($row["formationEtu"]=="ing")
       {
         $html_code = "<img src='img/entetePDF.png' style='width:100%'/>
                       <div class='demandestage' style='text-align:center;padding:50px;
                       font-family: Gotham, Helvetica, Arial'>
                         <h2>A l’attention du Directeur Général</h2>
                       </div>";
         $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
                       font-family: Gotham, Helvetica, Arial; margin-bottom:25px'>
                         Objet : Insertion d’étudiants de l’ISAMM au sein de votre entreprise
                       </div>";
         $html_code .= "<div class='Mme_Mr' style='text-align:left;margin-left:100px;
                       font-family: Gotham, Helvetica, Arial; margin-bottom:25px'>
                         Madame, Monsieur
                       </div>";
         $html_code .= "<div class='texte' >
                         <div class='p1' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:10px;
                         font-family: Gotham, Helvetica, Aria'>
                        &nbsp;&nbsp;&nbsp;&nbsp;Dans le cadre des formations dispensées à l’Institut Supérieur des Arts Multimédias
                        de la Manouba (ISAMM), le <b>cycle ingénieur</b> en <b><i>informatique multimédia</i></b>» est une
                        formation spécialisée dans le développement Web et la réalité virtuelle.
                         </div>
                         <div class='p2' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:10px;
                         font-family: Gotham, Helvetica, Arial;'>
                          &nbsp;&nbsp;&nbsp;&nbsp;Cette formation repose en partie sur l’insertion des étudiants au sein d’entreprises dans le cadre de stages
                          d’été et stages de fin d’étude.
                         </div>
                         <div class='p3' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:10px;
                         font-family: Gotham, Helvetica, Arial;'>
                        &nbsp;&nbsp;&nbsp;&nbsp;Nous venons par la présente vous demander de bien vouloir nous donner votre accord de principe pour l’insertion
                        d'étudiants de l’ISAMM au sein de votre entreprise en tant que stagiaires et vous invitons à nous faire parvenir
                        vos besoins (sujets de stage) en spécifiant le nombre de stagiaires à mettre à votre disposition.
                         </div>
                         <div class='p4' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:10px;
                         font-family: Gotham, Helvetica, Arial;'>
                          &nbsp;&nbsp;&nbsp;&nbsp;Nous portons à votre attention que nous disposons également de la possibilité d’établir
                          des accords de partenariat via des conventions qui permettent de faire bénéficier les
                          entreprises d’accueil du signe d’ « établissement formateur ».
                         </div>
                         <div class='p5' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:25px;
                         font-family: Gotham, Helvetica, Arial;'>
                          &nbsp;&nbsp;&nbsp;&nbsp;Restant à votre disposition pour tout complément d’information, nous vous prions d’agréer,
                           madame, monsieur, l’expression de nos salutations distinguées. <br/>Cordialement,
                         </div>
                         <div class='signature' style='text-align: justify; text-align-last: justify; margin-left:50px; margin-right:50px; margin-bottom:100px;
                         font-family: Gotham, Helvetica, Arial;'>
                          Youssef Ben Halima<br/>Directeur des études et des stages - ISAMM<br/>Tél : 71 603.497<br/>Fax : 71 603.450
                         </div>
                       </div>";
             $html_code .= "<img src='img/entetePDF.png' style='width:100%'/>
                           <div class='demandestage' style='text-align:center;padding:50px;
                           font-family: Gotham, Helvetica, Arial'>
                             <h2>A l’attention du responsable des  ressources humaines</h2>
                           </div>";
       }
     }
   }
   //$html_code .= "<p style='width:100%;'><h1>Bonjour Mr.".$row["nomEtu"]."</h1></p>";
   $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
                 font-family: Gotham, Helvetica, Arial; margin-bottom:25px'>
                   <b>Objet : <u>Placement en stage</u></b>
                 </div>";
   $html_code .= "<div class='Mme_Mr' style='text-align:left;margin-left:100px;
                 font-family: Gotham, Helvetica, Arial; margin-bottom:25px'>
                   Madame, Monsieur
                 </div>";
   $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
                 font-family: Gotham, Helvetica, Arial; margin-bottom:25px'>
                   Nous vous remercions d’avoir  donné votre accord pour l’accueil,
                   au sein de votre entreprise, de l’étudiant (e ) :
                 </div>";
  $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
               font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
                 <b>Nom et prénom:</b> ".$row['nomEtu']." ".$row['prenomEtu']."
               </div>";
  $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
            font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
              <b>CIN:</b> ".$row['cinEtu']."
            </div>";
 if ($row['niveauEtu']=='premiere') {
   $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
             font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
               <b>Inscrit en :</b> 1ère année ";
 }
 else {
   if ($row['niveauEtu']=='deuxieme') {
     $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
               font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
                 <b>Inscrit en :</b> 2ème année ";
   }
   else {
     if ($row['niveauEtu']=='troisieme') {
       $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
                 font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
                   <b>Inscrit en :</b> 3ème année ";
     }
   }
 }
 if ($row['formationEtu']=='ing') {
   $html_code .= "Cycle ingénieur en informatique multimédia
             </div>";
 }
 else {
   if ($row['formationEtu']=='im') {
     $html_code .= "Licence fondamentale en Informatique  et  Multimédia (IM)
               </div>";
   }
   else {
     if ($row['formationEtu']=='cm') {
       $html_code .= "Licence appliquée en Communication Multimédia (CM)
                 </div>";
     }
     else {
       if ($row['formationEtu']=='av') {
         $html_code .= "Licence appliquée en cinéma et audiovisuel
                   </div>";
       }
     }
   }
 }
 if ($row['typeStage']=='pfe') {
   $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
                font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
                  <b>dans le cadre d’un :</b> stage de fin d'études
                </div>";
 }
 else {
   if ($row['typeStage']=='obligatoire') {
     $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
                  font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
                    <b>dans le cadre d’un :</b> stage obligatoire
                  </div>";
   }
   else {
     if ($row['typeStage']=='non_obligatoire') {
       $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
                    font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
                      <b>dans le cadre d’un :</b> stage non obligatoire
                    </div>";
     }
   }
 }
 $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
              font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
                <b>du </b>".$row['dateD']." au ".$row['dateF']."
              </div>";
 $html_code .= "<div class='objet' style='text-align:left; margin-left:50px;
             font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
               &nbsp;&nbsp;&nbsp;&nbsp;Restant à votre disposition pour tout complément d’information, nous vous
               prions d’agréer, madame, monsieur, l’expression de nos salutations distinguées.<br/><br/>Cordialement,<br/><br/>
               Youssef Ben Halima<br/>Directeur des études et des stages - ISAMM<br/>Tél : 71 603.497<br/>Fax : 71 603.450
             </div>";
 $html_code .= "<div class='objet' style='text-align-last:justify; margin-left:50px;
             font-family: Gotham, Helvetica, Arial; margin-bottom:25px;'>
               <b>Nom de l’entreprise d’accueil : </b>".$row['nomEnt']."<br/><div style='float:right;'><b>Cachet et signature </b></div>
             </div>";

   $pdf = new Pdf();
   $pdf->load_html($html_code);
   $pdf->render();
   $file = $pdf->output();
   file_put_contents('..\DemandeStagePDF/'.$file_name, $file);


   $mail = new PHPMailer(true);
   try {
       $mail->SMTPDebug = 2;
       $mail->isSMTP();
       $mail->Host = 'smtp.gmail.com';
       $mail->SMTPAuth = true;
       $mail->Username = 'isamm.internship@gmail.com';
       $mail->Password = 'isamm2018';
       $mail->SMTPSecure = 'tls';
       $mail->Port = 587;
       $mail->setFrom('isamm.internship@gmail.com');
       $mail->addAddress("$row[emailEtu]");
       $mail->isHTML(true);
       $mail->AddAttachment('..\DemandeStagePDF/'.$file_name);
       $mail->Subject = 'DEMANDE DE STAGE';
       $mail->Body    = $row["nomEtu"].' '.$row["prenomEtu"].'<br>Vous trouvez ci-joint votre demande de stage sign&eacute;e.';
       $mail->send();
       echo 'Message has been sent';
   } catch (Exception $e) {
       echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
   }


   $query = "DELETE FROM stage WHERE cinEtu = '".$id."'";
   mysqli_query($connect, $query);
   $html_code="";
 }
}
?>
</body>
</html>
