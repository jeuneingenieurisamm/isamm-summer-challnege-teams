<!DOCTYPE html>
<html>
<head>
</head>
<body>
<?php
include('pdf.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'phpmailer/vendor/autoload.php';
$connect = mysqli_connect("localhost", "root", "", "stage_affect");
if(isset($_POST["id"]))
{
 foreach($_POST["id"] as $id)
 {
   $query1 = "SELECT * FROM lettreaff where cinEtu = $id";
   $result = mysqli_query($connect, $query1);
   $row = mysqli_fetch_array($result);
   $mail = new PHPMailer(true);
   try {
       $mail->SMTPDebug = 2;
       $mail->isSMTP();
       $mail->Host = 'smtp.gmail.com';
       $mail->SMTPAuth = true;
       $mail->Username = 'isamm.internship@gmail.com';
       $mail->Password = 'isamm2018';
       $mail->SMTPSecure = 'tls';
       $mail->Port = 587;
       $mail->setFrom('isamm.internship@gmail.com');
       $mail->addAddress("$row[emailEtu]");
       $mail->isHTML(true);
       $mail->Subject = 'LETTRE D\'AFFECTATION';
       $mail->Body    = $row["nomEtu"].' '.$row["prenomEtu"].'<br>CIN:'.$row["cinEtu"].'<br>Votre lettre d\'affectation a &eacute;t&eacute; refus&eacute;e';
       $mail->send();
       echo 'Message has been sent';
   } catch (Exception $e) {
       echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
   }


   $query = "DELETE FROM lettreaff WHERE cinEtu = '".$id."'";
   mysqli_query($connect, $query);
 }
}
?>
</body>
</html>
