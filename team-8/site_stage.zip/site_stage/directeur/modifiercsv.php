<?php
$connect = mysqli_connect("localhost", "root", "",'stage_affect');
$cin=$_POST['cin'];
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$query = "UPDATE liste_csv set nomEtu='$nom' , prenomEtu='$prenom' where cinEtu='$cin'";
mysqli_query($connect, $query);

?>
