<?php
$connect = mysqli_connect("localhost", "root", "",'stage_affect');
$file = fopen($_FILES['liste']['name'],"r");
while (!feof($file)) {
  $content=fgetcsv($file,100,";");
  $query = "INSERT into liste_csv(cinEtu, nomEtu, prenomEtu) values('$content[0]','$content[1]', '$content[2]')";
  mysqli_query($connect, $query);
}
header('Location: direction_stage.php');
?>
