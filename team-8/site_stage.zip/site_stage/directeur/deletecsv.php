<?php
$connect = mysqli_connect("localhost", "root", "", "stage_affect");
if(isset($_POST["id"]))
{
 foreach($_POST["id"] as $id)
 {
  $query = "DELETE FROM liste_csv WHERE cinEtu = '".$id."'";
  mysqli_query($connect, $query);
 }
}
?>
