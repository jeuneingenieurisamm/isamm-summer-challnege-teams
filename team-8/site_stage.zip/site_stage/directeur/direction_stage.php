<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="img/logo isamm.png" />
<link rel="stylesheet" type="text/css" href="cssfile.css" />
<link rel="stylesheet" type="text/css" href="css/cssfileDirect.css" />
<link rel="stylesheet" type="text/css" href="css/Squares.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title>ISAMM</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function() {
  $("a").on('click', function(event) {
    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function() {
        window.location.hash = hash;
      });
    }
  });
});

$(window).scroll(function(){

    if($(this).scrollTop() >= 510 && $(this).scrollTop() <= 550)
    {
        $(".colorlayer1").slideUp();
        $(".colorlayer2").slideUp();
        $(".colorlayer3").slideUp();
        $(".titre").delay(1000).fadeIn().css({"visibility":"visible"});
    }
});
</script>
<script>
$(document).ready(function() {
var time = document.getElementById("time");
var ctx = time.getContext("2d");
var width = (time.width = window.innerWidth);
var height = (time.height = window.innerHeight);

setInterval(function() {
  var currentTime = new Date();
  var formattedTime = currentTime.toLocaleTimeString();

  ctx.clearRect(0, 0, width, height);
  ctx.font = "100% Lato, sans-serif";
  ctx.fillStyle = '#036';
  ctx.textAlign = "center";
  if((formattedTime>"12:00:00")&&(formattedTime<"23:59:59"))
  {
    ctx.fillText(formattedTime+" pm", width/2 , height/1.5 );
  }
  else
  {
    ctx.fillText(formattedTime+" am", width/2 , height/1.5 );
  }
}, 1000);
});
</script>
</head>


<body onload="myFunction()" style="margin:0;">


  <div id="loader">
    <div class="square"></div>
    <div class="square"></div>
    <div class="square last"></div>
    <div class="square clear"></div>
    <div class="square"></div>
    <div class="square last"></div>
    <div class="square clear"></div>
    <div class="square "></div>
    <div class="square last"></div>
  </div>


  <div id="wrapper" style="display:none; background-color:#fff">
    <div class="header-wrapper">
      <header>
        <div class="bg">
          <div></div>
          <nav>
            <a href="home.html"><img src="img/logo isamm.png" class="logo"/></a>
            <div class="navbar">
              <a href="direction_stage.php">Accueil</a>
              <a href="#services">Services</a>
            </div>
          </nav>
          <canvas id="time">
          </canvas>
          <div class="directeur">DIRECTEUR DES ETUDES ET STAGES</div>
        </div>
      </header>
    </div>
    <div id="services">
      <div class="container">
        <div class="consulter">
          <div class="colorlayer1"></div>
          <div class="consulterimg">
            <div class="middle">
              <h2>Consulter</h2>
              <div class="desc">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                <a href="#consultersect"><input type="button" class="consulterbtn" value="Consulter"/></a>
              </div>
            </div>
          </div>
        </div>
        <div class="uploader">
          <div class="colorlayer2"></div>
          <div class="uploaderimg">
            <div class="middle">
              <h2>Uploader</h2>
              <div class="desc"
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                <a href="#uploadersect"><input type="button" class="uploaderbtn" value="Uploder"/></a>
              </div>
            </div>
          </div>
        </div>
        <div class="modifier">
          <div class="colorlayer3"></div>
          <div class="modifierimg">
            <div class="middle">
              <h2>Modifier</h2>
              <div class="desc">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                <a href="#modifiersect"><input type="button" class="modifierbtn" value="Modifer"/></a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="rapide">
        POUR UN SERVICE RAPIDE ET EFFICACE
      </div>
      <div id="consultersect">
        <div class="titre" style="visibility: hidden;margin-bottom:40px;">
          <div class="leftside"></div>
          <div class="consult">
            CONSULTER LA LISTE DES ETUDIANTS
          </div>
        </div>
        <div class="listedemande">
          <?php
          $connect = mysqli_connect("localhost", "root", "",'stage_affect');

          //affichage de la liste csv ( droit de stage)
          $q="select * from stage where cinEtu != 0";
          $r=mysqli_query($connect, $q);
          echo "<table>";
          echo "<tr>";
          echo "<th><h3>CIN</h3></th>";
          echo "<th><h3>NOM</h3></th>";
          echo "<th><h3>PRENOM</h3></th>";
          echo "<th><h3>NIVEAU</h3></th>";
          echo "<th><h3>FORMATION</h3></th>";
          echo "<th><h3>TYPE DE STAGE</h3></th>";
          echo "<th><h3>DATE DEBUT</h3></th>";
          echo "<th><h3>DATE FIN</h3></th>";
          echo "<th><h3>NOM D'ENTREPRISE</h3></th>";
          echo "<th><h3>EMAIL</h3></th>";
          echo "</tr>";
          foreach ($r as $key) {
            echo "<tr class='content'>";
            foreach ($key as $key1 => $value) {
              echo "<td>";
              echo "$value <br/>";
              echo "</td>";
            }
            echo "</tr>";
          }
          echo "</table>";
          ?>

        </div>
      </div>
      <div id="uploadersect">
        <div class="titre" style="visibility: hidden;margin-bottom:40px;">
          <div class="upload">
            UPLOADER LA LISTE DES ETUDIANTS
          </div>
          <div class="leftside"></div>
        </div>
        <div class="uploaderliste">
          <form enctype="multipart/form-data" method="post" action="uploader.php">
            <tr>
              <td><input type="file" name="liste"/></td>
              <td><input type="submit" class="filecsv"></td>
            </tr>
          </form>
        </div>
      </div>
      <div id="modifiersect">
        <div class="titre" style="visibility: hidden;margin-bottom:40px;">
          <div class="leftside"></div>
          <div class="modifier">
            MODIFIER LA LISTE DES ETUDIANTS
          </div>
        </div>
        <a href="#modifiercsv"><input type="button" class="modif" value="Modifier"></a>
        <a href="#ajoutercsv"><input type="button" class="ajout" value="Ajouter"></a>
        <a href="#supprimercsv"><input type="button" class="supp" value="Supprimer"></a>
        <div class="modifierliste">
          <form id="modifiercsv" style="display:none;" method="post">
            <div class="formname" style="text-align:center; color:#036; font-size:50px">Modifer</div><br/>
            <label for="cin">CIN:</label>
            <input type="text" id="cin" name="cin"/><br/><br/>
            <label for="nom">Nom:</label>
            <input type="text" id="nom" name="nom"/><br/><br/>
            <label for="prenom">Prénom:</label>
            <input type="text" id="prenom" name="prenom"/><br/><br/>
            <input type="button" class="submitbutt" id="modifierbutt" value="Modifier"/>
            <input type="reset" class="resetbutt"/><br/>
          </form>
          <form id="ajoutercsv" style="display:none;" method="post">
            <div class="formname" style="text-align:center; color:#036; font-size:50px">Ajouter</div><br/>
            <label for="cin2">CIN:</label>
            <input type="text" id="cin2" name="cin2"/><br/><br/>
            <label for="nom2">Nom:</label>
            <input type="text" id="nom2" name="nom2"/><br/><br/>
            <label for="prenom2">Prénom:</label>
            <input type="text" id="prenom2" name="prenom2"/><br/><br/>
            <input type="button" class="submitbutt" id="ajouterbutt" value="Ajouter"/>
            <input type="reset" class="resetbutt"/><br/>
          </form>


          <div id="supprimercsv" style="display:none;">
            <div class="liste">
              <?php
              $connect = mysqli_connect("localhost", "root", "",'stage_affect');

              $q="select * from liste_csv where cinEtu != 0";
              $r=mysqli_query($connect, $q);
              echo "<table>";
              echo "<tr>";
              echo "<th><h3>CIN</h3></th>";
              echo "<th><h3>NOM</h3></th>";
              echo "<th><h3>PRENOM</h3></th>";
              echo "<th style=color:red>X</th>";
              echo "</tr>";
              while($row=mysqli_fetch_array($r))
              {
                ?>
                <tr id="<?php echo $row["cinEtu"];?>">
                  <td><?php echo $row["cinEtu"];?></td>
                  <td><?php echo $row["nomEtu"];?></td>
                  <td><?php echo $row["prenomEtu"];?></td>
                  <td><input type=checkbox name="deleteEtu[]" class="delete" value="<?php echo $row["cinEtu"];?>"/></td>
                </tr>
                <?php
              }
              echo "</table>";
              ?>
            </div>
            <p>
              <div align="center">
                <button name="deletebutt" id="deletebutt" type="button" class="deletebutt">Supprimer</button>
              </div>
            </p>
          </div>
        </div>
      </div>
    </div>
    <footer>All Rights Reserved.<br>Malèk et Louay &copy; 2018</footer>
  </div>

  <script>
    var x;

    function myFunction() {
        x = setTimeout(showPage, 3000);
    }

    function showPage() {
      document.getElementById("loader").style.display = "none";
      document.getElementById("wrapper").style.display = "block";
    }
  </script>

  <script>
  $(document).ready(function(){
      $(".modif").click(function(){
          $("#modifiercsv").show();
          $("#ajoutercsv").hide();
          $("#supprimercsv").hide();
      });
      $(".ajout").click(function(){
          $("#ajoutercsv").show();
          $("#modifiercsv").hide();
          $("#supprimercsv").hide();
      });
      $(".supp").click(function(){
          $("#supprimercsv").show();
          $("#modifiercsv").hide();
          $("#ajoutercsv").hide();
      });
  });
  </script>
  <script>
  $(document).ready(function(){
      $("#deletebutt").click(function(){
        if(confirm("Êtes-vous sûr ?"))
        {
           var id = [];

           $(':checkbox:checked').each(function(i){
            id[i] = $(this).val();
          });

         if(id.length === 0)
         {
          alert("Veuillez sélectionner au moins une case à cocher");
         }
         else
         {
          $.ajax({
           url:'deletecsv.php',
           method:'POST',
           data:{id:id},
           success:function(){
              for(var i=0; i<id.length; i++)
              {
                 $('tr#'+id[i]+'').css('background-color', '#ccc');
                 $('tr#'+id[i]+'').fadeOut('slow');
              }
            }
          });
         }
        }
        else
        {
         return false;
        }
      });
  });

  $(document).ready(function(){
    $("#modifierbutt").click(function(){
      if(confirm("Êtes-vous sûr ?"))
      {
        var nom=$("#nom").val();
        var prenom=$("#prenom").val();
        var cin=$("#cin").val();
        $.ajax({
          url:'modifiercsv.php',
          method:'POST',
          data:{cin:cin, nom:nom, prenom:prenom},
          success:function(){
            $('#modifiercsv')[0].reset();
          }
        });
      }
    });
  });
  $(document).ready(function(){
    $("#ajouterbutt").click(function(){
        var nom=$("#nom2").val();
        var prenom=$("#prenom2").val();
        var cin=$("#cin2").val();
        $.ajax({
          url:'ajoutercsv.php',
          method:'POST',
          data:{cin:cin, nom:nom, prenom:prenom},
          success:function(){
            $('#ajoutercsv')[0].reset();
          }
        });
    });
  });
</script>
</body>
</html>
