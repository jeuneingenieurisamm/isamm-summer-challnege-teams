<?php
$connect = mysqli_connect("localhost", "root", "",'stage_affect');
$cin=$_POST['cin'];
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$query = "INSERT into liste_csv(cinEtu, nomEtu, prenomEtu) values('$cin','$nom', '$prenom')";
mysqli_query($connect, $query);
?>
